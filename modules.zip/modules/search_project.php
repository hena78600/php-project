<?php
require '../function.php';
$con = connect_db();
$id = $_SESSION['emp'];

 try{
if(isset ($_POST['prjid'])){
    $prjid = sanitizeString($_POST['prjid']);
 ?>    <table class="table table-striped table-hover">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                          <col width="120">
                           <col width="120">
                          <col width="120">
                          
<tr>
    <th>Project Id</th>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Street</th>
    <th>Country</th>
    <th>ZIP</th>
    <th>Avail Time</th>
    <th>Project Type</th>
    <th>Project Desc</th>
    <th>Currency</th>
    <th>Amount</th>
    <th>S Date</th>
    <th>E Date</th>
</tr>
  
                    <?php
                                           $get_res = mysqli_query($con, "Select * from project where project_id=$prjid AND executive_id=$id;");
                                            while($res = mysqli_fetch_assoc($get_res)){
                                                ?><tr><?php
                                               
                                                    ?><td><?php
                                                    echo $res['project_id']; 
                                                    ?></td><td><?php
                                                    echo $res['name']; 
                                                    ?></td><?php
                                                    ?><td><?php
                                                    echo $res['email']; 
                                                    ?></td><td><?php
                                                    echo $res['phone']; 
                                                    ?></td><?php
                                                    ?><td><?php
                                                    echo $res['street']; 
                                                    ?></td><td><?php
                                                    echo $res['country']; 
                                                    ?></td><?php
                                                    ?><td><?php
                                                    echo $res['zip']; 
                                                    ?></td><td><?php
                                                    echo $res['time']; 
                                                    ?></td><?php
                                                    ?><td><?php
                                                    echo $res['prj_type']; 
                                                    ?></td><td><?php
                                                    echo $res['prj_desc']; 
                                                    ?></td><?php
                                                    ?><td><?php
                                                    echo $res['currency']; 
                                                    ?></td><td><?php
                                                    echo $res['amount']; 
                                                    ?></td><td><?php
                                                    echo $res['start_date']; 
                                                    ?></td><td><?php
                                                    echo $res['end_date']; 
                                                    ?></td><?php
                                                
                                                
                                              ?></tr><?php
                     } 
                     ?>
                    
                    
                    
                    </table><?php
   
   }
   } 
   catch(Exception $e)
   {
       
       echo "Please Enter Correct Project ID";
       
   }