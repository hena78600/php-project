<?php
require '../function.php';
$con = connect_db();
if ($_POST['inputName']){
    $name = $_POST['inputName'];
    $id = $_POST['inputEmpId'];
    $join = $_POST['inputJoin'];
    $verify = $_POST['inputVerify'];
    $dept = $_POST['inputDept'] ;
    $desg = $_POST['inputDesg'] ;
    $shift = $_POST['inputShift'] ;
    $status = $_POST['inputStatus'] ;
    $dob = $_POST['inputDob'] ; 
    $gender = $_POST['gender'] ;
    $group = $_POST['inputGroup'];
    
    if(mysqli_query($con, "Update employee set name = '$name', id='$id', joining = '$join', verified = '$verify', dept = '$dept', desg = '$desg', shift = '$shift', status = '$status', dob = '$dob', gender = '$gender', bgroup = '$group' where id = '$id' ")){
        echo 'Employee Information successfully updated';
    }else{
        echo 'Some error occured';
    }
    
}