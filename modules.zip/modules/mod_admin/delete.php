<?php
require '../../function.php';
$con = connect_db();
if(isset($_POST['dept'])){
    $dept = sanitizeString($_POST['dept']);
    if(mysqli_query($con, "Delete from department where dept_id = '$dept' ")){
        echo 'success';
    }else{
        echo 'Some error occured';
    }
}elseif(isset($_POST['desg'])){
    $desg = sanitizeString($_POST['desg']);
    if(mysqli_query($con, "Delete from designation where desg_id = '$desg' ")){
        echo 'success';
    }else{
        echo 'Some error occured';
    }
}