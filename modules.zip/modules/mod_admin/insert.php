<?php
require '../../function.php';
$con = connect_db();
if(isset($_POST['dept']) && isset($_POST['parent'])){
    $dept = sanitizeString($_POST['dept']);
    $parent = sanitizeString($_POST['parent']);
    if(mysqli_query($con, "Insert into department (name, parent) values('$dept', '$parent')")){
        echo 'success';
    }else{
        echo 'Error inserting new department';
    }
}elseif (isset($_POST['desg']) && isset($_POST['department'])) {
    $desg = sanitizeString($_POST['desg']);
    $dept = sanitizeString($_POST['department']);
    if(mysqli_query($con, "Insert into designation (name, dept) values('$desg', '$dept')")){
        echo 'success';
    }else{
        echo 'Error inserting new department';
    }
}