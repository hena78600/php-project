<?php
require '../../function.php';
$con = connect_db();
if(isset($_POST['dept'])){
    if($_POST['type'] == 'search'){
        $id = sanitizeString($_POST['dept']);
        $get = mysqli_query($con, "Select * from department where dept_id= '$id'");
        $row = mysqli_fetch_assoc($get);
        echo $row['name'].",".$row['parent'];
    }else{
        $id = sanitizeString($_POST['dept']);
        $name = sanitizeString($_POST['name']);
        $parent = sanitizeString($_POST['parent']);
        if(mysqli_query($con, "Update department set name='$name', parent='$parent' where dept_id='$id'")){
            echo 'success';
        }else{
            echo 'Error editing department. Please try again letter';
        }
    }
}elseif(isset($_POST['desg'])){
    if($_POST['type'] == 'search'){
        $id = sanitizeString($_POST['desg']);
        $get = mysqli_query($con, "Select * from designation where desg_id= '$id'");
        $row = mysqli_fetch_assoc($get);
        echo $row['name'].",".$row['dept'];
    }else{
        $id = sanitizeString($_POST['desg']);
        $name = sanitizeString($_POST['name']);
        $dept = sanitizeString($_POST['department']);
        if(mysqli_query($con, "Update designation set name='$name', dept='$dept' where desg_id='$id'")){
            echo 'success';
        }else{
            echo 'Error editing department. Please try again letter';
        }
    }
}