<?php
require '../function.php';
$con = connect_db();
if(isset($_GET['manager'], $_GET['amount'])){
    $manager = sanitizeString($_GET['manager']);
    $amount = sanitizeString($_GET['amount']);
    $approval_status='1';
    $prjid=sanitizeString($_GET['prjid']);
    $id = $_SESSION['emp'];
 
    
    if(mysqli_query($con, "UPDATE project SET pm = '$manager', amount = $amount, approval_status=$approval_status WHERE project_id=$prjid;")){
        echo 'Project updated successfully';
        ?>

<script type="text/javascript">alert('Project Updated Succesfully! This Tab will Close Now!!')</script>
<script type="text/javascript">window.close();</script><?php
        
    }else{
        echo 'Please fill Mandatory Fields';
        
    }
    
    
}