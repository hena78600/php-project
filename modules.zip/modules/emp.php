<?php
require '../function.php';
$con = connect_db();
if(isset($_POST['findId'])){
    $id = $_POST['findId'];
    $get = mysqli_query($con, "Select id from employee where id='$id'");
    if(mysqli_num_rows($get) == '0'){
        echo 'User id available';
    }else{
        echo 'success';
    }
}elseif(isset ($_POST['id'])){
    $id = sanitizeString($_POST['id']);
    $name = sanitizeString($_POST['name']);
    $email = sanitizeString($_POST['email']);
    $phone = sanitizeString($_POST['phone']);
    $join = sanitizeString($_POST['join']);
    $dept = sanitizeString($_POST['dept']);
    $desg = sanitizeString($_POST['desg']);
    $shift = sanitizeString($_POST['shift']);
    $status = sanitizeString($_POST['status']);
    $duration = sanitizeString($_POST['duration']);
    $date = date('Y-m-d');
    $pass = md5($id);
    
    if(mysqli_query($con, "Insert into employee (id, status, date, name, email, phone, password, dept, desg, shift, duration, joining) values ('$id', '$status', '$date', '$name', '$email', '$phone', '$pass', '$dept', '$desg', '$shift', '$duration', '$join');")){
        $set_dept = mysqli_query($con, "Insert into assign (emp_id, type, type_id, date) value('$id', 'Department', '$dept', '$join')");
        $set_dept = mysqli_query($con, "Insert into assign (emp_id, type, type_id, date) value('$id', 'Designation', '$desg', '$join')");
        $set_dept = mysqli_query($con, "Insert into assign (emp_id, type, type_id, date) value('$id', 'Shift', '$shift', '$join')");
        echo 'Employee Id RLI'.$id.' successfully added';
    }else{
        echo 'Employee Id RLI'.$id.' not added';
    } 
}elseif(isset ($_POST['searchEmp'])){
    $data = $_POST['searchEmp'];
    if (!preg_match('/[^A-Z a-z]/', $data)){
        $check = "Select id, name, dept, desg, verified, status from employee where name = '$data'";
    }else{
        $check = "Select * from employee where id = '$data'";
    }
    $get = mysqli_query($con, $check);
    if(mysqli_num_rows($get) == 0 ){
        echo 'No records found';
    }else{
        ?>
        <table class="table table-striped table-hover" style="margin-top: 30px">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Verification</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($resEmp = mysqli_fetch_assoc($get)) { ?>
                <tr>
                    <td><?php echo $resEmp['id']; ?></td>
                    <td><?php echo $resEmp['name']; ?></td>
                    <td><?php echo $resEmp['dept']; ?></td>
                    <td><?php echo $resEmp['desg']; ?></td>
                    <td><?php if($resEmp['verified'] === '0') { echo 'Not Verified'; } else{ echo 'Verified'; } ?></td>
                    <td><?php echo $resEmp['status']; ?></td>
                    <td><a href="edit-emp.php?id=<?php echo $resEmp['id']; ?>" class="btn btn-primary btn-xs">Edit</a></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php }
} ?>