<?php
require '../function.php';
$con = connect_db();
$id = $_SESSION['emp'];

 try{
if(isset ($_POST['prjid'])){
    $prjid = sanitizeString($_POST['prjid']);
    $live_status='';
    $comment_by_name='';
    $comment_by_desg='';
 ?>    <table>
                          <col width="220">
                          <col width="220">
                          <col width="220"><col width="220">
                          
                          
                          
<tr>
    <th>Project Id</th>
    <th>Comment</th>
    <th>Comment By</th>
    <th>Commented Date</th>
    <th>Project Live Status</th>
    
</tr>
  
                    <?php
                                           $get_res = mysqli_query($con, "Select * from comment where project_id=$prjid ORDER BY date DESC");
                                           
                                           $get_res1 = mysqli_query($con, "Select project_live_status from project where project_id=$prjid");
                                            while($res1 = mysqli_fetch_assoc($get_res1)){$live_status=$res1['project_live_status'];}
                                            while($res = mysqli_fetch_assoc($get_res)){
                                                ?><tr><?php
                                               
                                                    ?><td><?php
                                                    echo $res['project_id']; 
                                                    ?></td><td><?php
                                                    echo $res['comment']; 
                                                    ?></td><?php
                                                    ?><td><?php
                                                     $get_res2 = mysqli_query($con, "Select name,desg from employee where id='".$res['comment_by']."'");
                                                    while($res2 = mysqli_fetch_assoc($get_res2)){
                                                     $comment_by_name=$res2['name'];
                                                     $comment_by_desg=$res2['desg'];
                                                     
                                                     
                                                    }
                                                    echo $res['comment_by'].'('.$comment_by_name.')'.'**'.$comment_by_desg."**"; 
                                                   
                                                    ?></td><td><?php echo $res['date']?></td><td><?php
                                                    echo $live_status; 
                                                    ?></td><?php
                                                
                                                
                                              ?></tr><?php
                     } 
                     ?>
                    
                    
                    
                    </table><?php
   
   }
   } 
   catch(Exception $e)
   {
       
       echo "Please Enter Correct Project ID";
       
   }