<?php
require '../function.php';
$con = connect_db();
$id = $_SESSION['emp'];

 try{
if(isset ($_POST['exeid'])){
   
    $exeid = sanitizeString($_POST['exeid']);
 ?>    <table class="table table-striped table-hover">
                          <col width="500">
                          <col width="500">
                          <col width="500">
                          
                          
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Designation</th>
    
</tr>
  
<?php
   $get_res = mysqli_query($con, "Select * from employee where id=$exeid;");
    
    if($get_res){
   while($res = mysqli_fetch_assoc($get_res)){
        ?><tr><?php

            ?><td><?php
            echo $res['name']; 
            ?></td><td><?php
            echo $res['email']; 
            ?></td><td><?php
            echo $res['desg']; 
            ?></td><?php
            


      ?></tr><?php
    } }else{echo 'Please Enter Employee ID only!!';}
                     ?>
                    
                    
                    
                    </table><?php
   
   }
   } 
   catch(Exception $e)
   {
       
       echo "Please Enter Correct Project ID";
       
   }