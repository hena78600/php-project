<?php
require '../function.php';
$con = connect_db();
if(isset($_GET['prjid'], $_GET['empid'])){
    $prjid = sanitizeString($_GET['prjid']);
    $empid = sanitizeString($_GET['empid']);
  
    $id = $_SESSION['emp'];
 
      
      if(mysqli_query($con, "Insert into project_assign(project_id, id, project_live_status) values ($prjid, $empid, 'Open')"))
      {
       
         ?>

<script type="text/javascript">alert('Assigned Successfully!!')</script>
<script type="text/javascript">window.close();</script><?php
        
       
        
    }else{
        echo 'Please fill Mandatory Fields';
        
    }
    
    
}