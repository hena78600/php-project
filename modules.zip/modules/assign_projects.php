<?php
require '../function.php';
$con = connect_db();
if(isset($_GET['prjid'], $_GET['empid'], $_GET['sdate'], $_GET['edate'])){
    $prjid = sanitizeString($_GET['prjid']);
    $empid = sanitizeString($_GET['empid']);
    $sdate = sanitizeString($_GET['sdate']);
    $edate = sanitizeString($_GET['edate']);
  
    $id = $_SESSION['emp'];
 
    
    if(mysqli_query($con, "UPDATE project SET start_date = '$sdate', end_date = '$edate', project_live_status='Open' WHERE project_id=$prjid;")){
        
      if(mysqli_query($con, "Insert into project_assign(project_id, id) values ($prjid, $empid)"))
      {
       
         ?>

<script type="text/javascript">alert('Assigned Successfully!!')</script>
<script type="text/javascript">window.close();</script><?php
        
       
        
    }}else{
        echo 'Please fill Mandatory Fields';
        
    }
    
    
}