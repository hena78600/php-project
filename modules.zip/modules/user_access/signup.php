<?php
require '../../function.php';
if($_POST['inputName'] != '' && $_POST['inputEmpId'] != '' && $_POST['inputEmail'] != '' && $_POST['inputPassword'] !== ''){
    $con = connect_db();
    //Fetch the values
    if(isset($_POST['inputAdmin'])){
        $admin = 1;
    }else{
        $admin = 0;
    }
    $name = $_POST['inputName'];
    $emp = $_POST['inputEmpId'];
    $email = $_POST['inputEmail'];
    $pass = $_POST['inputPassword'];
    
    //Get current date and time
    $date = date('Y-m-d H:i:s');
    
    //Filter the data
    $name = sanitizeString($name);
    $emp = sanitizeString($emp);
    $email = sanitizeString($email);
    
    //Encrypt password 
    $pass = md5($pass);
    
    //Insert into employee table
    if (mysqli_query($con, "Insert into employee (id, is_admin, status, date, name, password, email) values ('$emp', '$admin', '1', '$date', '$name', '$pass', '$email')")){
        header("Location: ../../login.php");
        exit();
    }else{
        die('The system encountered an error. Please try after sometime.');
    }
    
}
