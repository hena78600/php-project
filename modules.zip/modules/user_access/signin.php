<?php
require '../../function.php';
if($_POST['username'] != '' && $_POST['password'] != ''){
    $con = connect_db();
    
    //Filter and fetch values
    $username = sanitizeString($_POST['username']);
    $password = sanitizeString($_POST['password']);
    
    //Encrypt the password
    $pass = md5($password);
    
    //Validate the values
    $get = mysqli_query($con, "Select id from employee where id='$username' and password='$pass' ");
    if(mysqli_num_rows($get) == 1){
        $_SESSION['emp'] = $username;
        echo 'success';
    }else{
        echo 'Invalid Credentials';
    }
}