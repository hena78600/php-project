<?php
require '../function.php';
$con = connect_db();
if(isset($_POST['iname'], $_POST['email'],$_POST['phone'], $_POST['street'], $_POST['country'], $_POST['zip'], $_POST['time'], $_POST['type'], $_POST['desc'], $_POST['currency'], $_POST['amount'])){
    $name = sanitizeString($_POST['iname']);
    $email = sanitizeString($_POST['email']);
    $phone = sanitizeString($_POST['phone']);
    $street = sanitizeString($_POST['street']);
    $country = sanitizeString($_POST['country']);
    $zip = sanitizeString($_POST['zip']);
    $time = sanitizeString($_POST['time']);
    $type = sanitizeString($_POST['type']);
    $desc = sanitizeString($_POST['desc']);
    $currency = sanitizeString($_POST['currency']);
    $amount = sanitizeString($_POST['amount']);
    $id = $_SESSION['emp'];
   
    
    if(mysqli_query($con, "Insert into project(name, email, phone, street, country, zip, time, prj_type, prj_desc, currency, amount, executive_id, approval_status, project_live_status) values ('$name', '$email', '$phone', '$street', '$country', $zip, '$time', '$type', '$desc', '$currency', $amount, $id, '0', 'NA')")){
        echo 'Project Created successfully';
    }else{
        echo 'Please fill Mandatory Fields';
    }
    
    
}