<?php
require '../function.php';
$con = connect_db();
if(isset($_POST['dept'])){
    $dept = sanitizeString($_POST['dept']);
    if(mysqli_query($con, "Insert into department (name) values ('$dept')")){
        echo 'success';
    }else{
        echo 'Some error occured. Please try again.';
    }
}elseif(isset ($_POST['viewdept'])){
    $get = mysqli_query($con, "Select * from department");
    while($row = mysqli_fetch_assoc($get)){
        $data[] = array(
            'id'=> $row['dept_id'],
            'name' => $row['name']
        );
    }
    echo json_encode($data);
}elseif (isset($_POST['deldept'])) {
    $id = $_POST['deldept'];
    if(mysqli_query($con, "Delete from department where dept_id='$id'")){
        echo 'success';
    }else{
        echo 'Some error occured. Please try again.';
    }
}elseif(isset($_POST['desg'])) {
    $desg = sanitizeString($_POST['desg']);
    if(mysqli_query($con, "Insert into designation (name) values ('$desg')")){
        echo 'success';
    }else{
        echo 'Some error occured. Please try again.';
    }
}elseif(isset($_POST['viewdesg'])){
    $get = mysqli_query($con, "Select * from designation");
    while($row = mysqli_fetch_assoc($get)){
        $data[] = array(
            'id'=> $row['desg_id'],
            'name' => $row['name']
        );
    }
    echo json_encode($data);
}elseif (isset($_POST['deldesg'])) {
    $id = $_POST['deldesg'];
    if(mysqli_query($con, "Delete from designation where desg_id='$id'")){
        echo 'success';
    }else{
        echo 'Some error occured. Please try again.';
    }
}elseif(isset($_POST['shift'])) {
    $shift = sanitizeString($_POST['shift']);
    $login = sanitizeString($_POST['login']);
    $logout = sanitizeString($_POST['logout']);
    
    if(mysqli_query($con, "Insert into shift (name, login, logout) values ('$shift', '$login', '$logout')")){
        echo 'success';
    }else{
        echo 'Some error occured. Please try again.';
    }
}elseif(isset ($_POST['viewshift'])){
    $get = mysqli_query($con, "Select * from shift");
    while($row = mysqli_fetch_assoc($get)){
        $data[] = array(
            'id'=> $row['shift_id'],
            'name' => $row['name'],
            'login' => $row['login'],
            'logout' => $row['logout']
        );
    }
    echo json_encode($data);
}elseif(isset ($_POST['delshift'])){
    $id = $_POST['delshift'];
    if(mysqli_query($con, "Delete from shift where shift_id='$id'")){
        echo 'success';
    }else{
        echo 'Some error occured. Please try again.';
    }
}