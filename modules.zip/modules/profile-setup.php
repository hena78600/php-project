<?php
require '../function.php';
$con = connect_db();
if(isset($_POST['oldPass'])){
    if($_POST['oldPass'] !== '' && $_POST['newPass'] !== ''){
        $oldPass = md5($_POST['oldPass']);
        $newPass = md5($_POST['newPass']);
        $id = $_POST['id'];
        
        $get = mysqli_query($con, "Select id from employee where id='$id' and password = '$oldPass'");
        if(mysqli_num_rows($get) == 0){
            echo 'Invalid Password';
        }else{
            if(mysqli_query($con, "Update employee set password = '$newPass' where id='$id'")){
                echo 'Password changed';
            }else{
                echo 'Some error occured';
            }
        }
    }
}elseif (isset ($_POST['inputFather'])) {
    $id = $_SESSION['emp'];
    $dad = sanitizeString($_POST['inputFather']);
    $phone = sanitizeString($_POST['inputPhone']);
    $res = sanitizeString($_POST['inputResPhone']);
    $email = sanitizeString($_POST['inputEmail']);
    $dob = sanitizeString($_POST['inputDob']);
    $gender = sanitizeString($_POST['gender']);
    $group = sanitizeString($_POST['inputGroup']);
    $present = sanitizeString($_POST['inputPresent']);
    $permanent = sanitizeString($_POST['inputPermanent']);
    
    if(mysqli_query($con, "Update employee set phone='$phone', father='$dad', dob='$dob', gender='$gender', resphone='$res', bgroup='$group', present='$present', permanent='$permanent' where id = '$id'")){
        echo '<h5>Profile successfully updated</h5>';
    }else{
        echo '<h5>Some error occured. Please try again</h5>';
    }
    
}