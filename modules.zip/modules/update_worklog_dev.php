<?php
require '../function.php';
$con = connect_db();
if(isset($_GET['prjid'], $_GET['comment'])){
    $prjid = sanitizeString($_GET['prjid']);
    $comment = sanitizeString($_GET['comment']);
    
   $date=date('y-m-d');
    
    $id = $_SESSION['emp'];
 
    
   
      
      if(mysqli_query($con, "Insert into comment(project_id, comment, comment_by, date) values ($prjid, '$comment',$id, '$date')"))
      {
       
         ?>

<script type="text/javascript">alert('Worklog Updated!!')</script>
<?php
   header("Location:../developersaccess.php");     
       
        
    }else{
        echo 'Please fill Mandatory Fields';
        
    }
    
    
}