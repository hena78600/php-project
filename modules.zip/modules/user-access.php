<?php
include '../function.php';
$con = connect_db();
if(isset($_POST['reqType']) && $_POST['reqType'] == '1' ){
    if(isset($_POST['inputAdmin'])){
        if($_POST['inputName'] !== '' && $_POST['inputEmpId'] !== '' && $_POST['inputEmail'] !== '' && $_POST['inputPassword'] !== ''){
            $name = sanitizeString($_POST['inputName']);
            $id = sanitizeString($_POST['inputEmpId']);
            $email = sanitizeString($_POST['inputEmail']);
            $pass = md5($_POST['inputPassword']);
            $date = date('Y-m-d');
            if(mysqli_query($con, "Insert into employee (id, is_admin, status, date, name, email, password, verified) values ('$id', '1', 'Permanent', '$date', '$name', '$email', '$pass', '1')")){
                header("Location: ../login.php");
            }else{
                echo 'System encountered an error. Please try after sometime';
            }
        }else{
            header("Location: ../setup.php");
        }
    }else{
        $admin = 0;
    }
    
    
}elseif(isset($_POST['reqType']) && $_POST['reqType'] == '2'){
    if($_POST['username'] !== '' && $_POST['password'] !== ''){
        $id = $_POST['username'];
        $pass = md5($_POST['password']);
        $check = mysqli_query($con, "Select id from employee where id='$id' and password = '$pass' ");
        if(mysqli_num_rows($check) == 0){
            echo 'Invalid Credentials';
        }else{
            $row = mysqli_fetch_array($check);
            $_SESSION['emp']=$row['id'];
            echo 'success';
        }
    }else{
        header("Location: ../setup.php");
    }
}elseif(isset($_GET['loggedout'])){
    session_destroy();
    header("Location: ../login.php");
}